// src/components/About.js
import React from 'react';
import './About.css';
import { FaUser } from 'react-icons/fa';

function About() {
  return (
    <section id="about">
      <div className="about-container">
        <div className="about-text">
          {/* <h2><FaUser className="about-icon" /> About Me</h2> */}
          <h2><FaUser style={{ color: '#ffa500' }} /> About Me</h2>

          <p>
            Hardworking and passionate job seeker with strong organizational skills eager to secure entry-level Software Developer position. Ready to help team achieve company goals.
          </p>
          <a href="#contact" className="btn">Contact Me</a>
        </div>
        <div className="about-image">
          {/* <img src="/images/profile.jpg" alt="Profile" className="profile-image" /> */}
          <img src="/images/profile-1.jpg" alt="Profile" className="profile-image" />
        </div>
      </div>
    </section>
  );
}

export default About;
