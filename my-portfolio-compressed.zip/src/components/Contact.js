// src/components/Contact.js
import React from 'react';
import './Contact.css';
import { FaEnvelope, FaPhoneAlt, FaMapMarkerAlt, FaAddressBook } from 'react-icons/fa';

function Contact() {
  return (
    <section id="contact">
      <h2>
        <FaAddressBook style={{ color: '#FFB300', marginRight: '10px', fontSize: '2rem' }} />
        Contact Me
      </h2>
      <div className="contact-container">
        <div className="contact-info">
          <p><FaEnvelope className="contact-icon" /> 2200031199cseh1@gmail.com</p>
          <p><FaPhoneAlt className="contact-icon" /> +91 7989154141</p>
          <p><FaMapMarkerAlt className="contact-icon" /> Guntur, Andhra Pradesh</p>
        </div>
        <form className="contact-form">
          <input type="text" placeholder="Your Name" required />
          <input type="email" placeholder="Your Email" required />
          <textarea placeholder="Your Message" rows="4" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </section>
  );
}

export default Contact;
