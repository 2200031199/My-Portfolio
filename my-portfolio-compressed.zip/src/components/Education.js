// src/components/Education.js
import React from 'react';
import './Education.css';
import { FaGraduationCap } from 'react-icons/fa';

function Education() {
  const educationData = [
    {
      year: '2022 - 2026',
      degree: 'B.Tech in CSE',
      university: 'KL University',
      location: 'Vaddeswaram, India'
    },
    {
      year: '2020 - 2022',
      degree: 'Intermediate (MPC)',
      university: 'Narayana Jr College',
      location: 'Guntur, India'
    },
    {
      year: '2019 - 2020',
      degree: 'SSC',
      university: 'Narayana English Medium School',
      location: 'Guntur, India'
    }
  ];

  return (
    <section id="education">
      <h2><FaGraduationCap className="edu-icon" /> My Education</h2>
      <div className="timeline">
        {educationData.map((edu, index) => (
          <div key={index} className="timeline-item">
            <div className="timeline-date">{edu.year}</div>
            <div className="timeline-content">
              <h3>{edu.degree}</h3>
              <p>{edu.university}</p>
              <small>{edu.location}</small>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Education;
