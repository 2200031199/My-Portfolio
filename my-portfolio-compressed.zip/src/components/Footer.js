// src/components/Footer.js
import React from 'react';
import { FaGithub, FaLinkedin } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer style={{ 
      padding: '20px', 
      textAlign: 'center', 
      backgroundColor: 'white', 
      color: '#000'  // <- black text color
    }}>
      <p>&copy; My Portfolio</p>
      <p>Follow me on:</p>
      <div style={{ marginTop: '10px' }}>
        <a
          href="https://www.linkedin.com/in/tejaswi-veluri-6744b2287/"
          target="_blank"
          rel="noopener noreferrer"
          style={{ margin: '0 15px', fontSize: '1.5rem', color: '#0A66C2' }}
        >
          <FaLinkedin />
        </a>
        <a
          href="https://github.com/2200031199"
          target="_blank"
          rel="noopener noreferrer"
          style={{ margin: '0 15px', fontSize: '1.5rem', color: '#000' }}
        >
          <FaGithub />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
