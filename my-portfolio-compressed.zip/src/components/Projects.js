// src/components/Projects.js
import React, { useEffect, useState } from 'react';
import './Projects.css';
import { FaFolderOpen } from 'react-icons/fa'; // Import the folder icon

function Projects() {
  const [repos, setRepos] = useState([]);

  const highlightedProjects = [
    {
      id: "custom-1",
      title: "HTML ",
      description: "Developed an HTML profile page using Javascript.",
      demoLink: "#",
      codeLink: "https://github.com/2200031199/JSPROJECT31199.git"
    },
    {
      id: "custom-2",
      title: "Online Donation System",
      description: "A complete online donation platform built with PHP and MySQL.",
      demoLink: "#",
      codeLink: "https://github.com/2200031199/online-donation-system.git"
    },
    {
      id: "custom-3",
      title: "Flood Prediction Model",
      description: "A machine learning project using multi-linear regression to predict flood risk.",
      demoLink: "#",
      codeLink: "https://github.com/2200031199/FloodPredictionUsingMultiLinearRegreession.git"
    }
  ];

  // useEffect(() => {
  //   fetch('https://api.github.com/users/2200031199/repos')
  //     .then(response => response.json())
  //     .then(data => {
  //       const filtered = data.filter(
  //         repo =>
  //           !repo.fork &&
  //           !highlightedProjects.some(hp => repo.html_url === hp.codeLink)
  //       );
  //       setRepos(filtered);
  //     })
  //     .catch(error => console.error('Error fetching repos:', error));
  // }, []);

  return (
    <section id="projects">
      <h2>
        <FaFolderOpen style={{ color: '#FFB300', marginRight: '10px' }} />

        My Projects
      </h2>
      <div className="projects-grid">
        {highlightedProjects.map((project) => (
          <div className="project-card" key={project.id}>
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <div className="project-links">
              <a href={project.codeLink} target="_blank" rel="noopener noreferrer">GitHub</a>
              {/* <a href={project.demoLink} target="_blank" rel="noopener noreferrer">Live Demo</a> */}
            </div>
          </div>
        ))}
        {repos.map((repo) => (
          <div className="project-card" key={repo.id}>
            <h3>{repo.name}</h3>
            <p>{repo.description || "No description available."}</p>
            <div className="project-links">
              <a href={repo.html_url} target="_blank" rel="noopener noreferrer">GitHub</a>
              {repo.homepage && (
                <a href={repo.homepage} target="_blank" rel="noopener noreferrer">Live Demo</a>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Projects;
