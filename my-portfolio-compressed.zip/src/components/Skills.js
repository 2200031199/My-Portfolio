// src/components/Skills.js
import React from 'react';
import './Skills.css';
import { FaTools } from 'react-icons/fa';

function Skills() {
  const skills = [
    { name: 'C', percent: 90 },
    { name: 'HLML', percent: 85 },
    { name: 'CSS', percent: 80 },
    { name: 'React', percent: 75 },
    { name: 'Node.js', percent: 70 },
    { name: 'Java', percent: 75 },
    { name: 'MongoDB', percent: 70 },
    // { name: '', percent: 80 },
    // { name: 'Python', percent: 60 },
    // { name: 'Git & GitHub', percent: 85 }
  ];

  return (
    <section id="skills">
      <h2>
        <FaTools className="skills-icon" /> My Skills
      </h2>
      <div className="skills-grid">
        {skills.map((skill, index) => (
          <div className="skill-card" key={index}>
            <div className="circle small">
              <svg>
                <circle cx="40" cy="40" r="35"></circle>
                <circle
                  cx="40"
                  cy="40"
                  r="35"
                  style={{ strokeDashoffset: 220 - (220 * skill.percent) / 100 }}
                ></circle>
              </svg>
              <div className="number">
                {skill.percent}%
              </div>
            </div>
            <p>{skill.name}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Skills;
